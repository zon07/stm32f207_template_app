/*
 * File: simulink_app.c
 *
 * Code generated for Simulink model 'stm32f207_template_app'.
 *
 * Model version                  : 1.562
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Sat Jul  5 22:55:16 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. MISRA C:2012 guidelines
 *    2. Execution efficiency
 *    3. ROM efficiency
 *    4. RAM efficiency
 *    5. Traceability
 *    6. Safety precaution
 *    7. Debugging
 * Validation result: Not run
 */

#include "simulink_app.h"
#include "rtwtypes.h"
#include "simulink_apptypes.h"
#include "simulink_appprivate.h"
#include "can_control.h"

/* Named constants for Chart: '<S1>/Chart' */
#define stm32f207_template_app_IN_OFF  ((uint8_T)1U)
#define stm32f207_template_app_IN_ON   ((uint8_T)2U)

/* Exported data definition */

/* Volatile memory section */
/* Definition for custom storage class: Volatile */
volatile boolean_T BlueSwitch = true;  /* Referenced by: '<S1>/Constant' */
volatile boolean_T GreenSwitch = false;/* Referenced by: '<S1>/Constant1' */
volatile boolean_T RedSwitch = true;   /* Referenced by: '<S1>/Constant2' */

/* Block signals and states (default storage) */
DW_stm32f207_template_app_T stm32f207_template_app_DW;

/* Real-time model */
static RT_MODEL_stm32f207_template_a_T stm32f207_template_app_M_;
RT_MODEL_stm32f207_template_a_T *const stm32f207_template_app_M =
  &stm32f207_template_app_M_;
static void rate_scheduler(void);

/*
 *         This function updates active task flag for each subrate.
 *         The function is called at model base rate, hence the
 *         generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (stm32f207_template_app_M->Timing.TaskCounters.TID[1])++;
  if ((stm32f207_template_app_M->Timing.TaskCounters.TID[1]) > 1) {/* Sample time: [0.02s, 0.0s] */
    stm32f207_template_app_M->Timing.TaskCounters.TID[1] = 0;
  }

  (stm32f207_template_app_M->Timing.TaskCounters.TID[2])++;
  if ((stm32f207_template_app_M->Timing.TaskCounters.TID[2]) > 49) {/* Sample time: [0.5s, 0.0s] */
    stm32f207_template_app_M->Timing.TaskCounters.TID[2] = 0;
  }

  (stm32f207_template_app_M->Timing.TaskCounters.TID[3])++;
  if ((stm32f207_template_app_M->Timing.TaskCounters.TID[3]) > 99) {/* Sample time: [1.0s, 0.0s] */
    stm32f207_template_app_M->Timing.TaskCounters.TID[3] = 0;
  }
}

/*
 * Output and update for function-call system:
 *    '<Root>/�anSendMsg'
 *    '<Root>/�anSendMsg1'
 */
void stm32f207_template_ap_anSendMsg(boolean_T *rty_result, const
  ConstB_anSendMsg_stm32f207_te_T *localC)
{
  /* CCaller: '<S2>/CanSendMessage1' incorporates:
   *  Constant: '<S2>/can'
   */
  *rty_result = CanSendMessage(0, &localC->BusAssignment);
}

/*
 * Output and update for function-call system:
 *    '<S11>/CAN send'
 *    '<S15>/CAN send'
 *    '<S19>/CAN send'
 */
void stm32f207_template_app_CANsend(const CAN_MESSAGE_BUS *rtu_canMsg, boolean_T
  *rty_result)
{
  CAN_Msg_t rtb_BusAssignment;
  int32_T i;
  uint32_T rtb_Cast_h;

  /* DataTypeConversion: '<S12>/Cast' */
  rtb_Cast_h = (uint32_T)rtu_canMsg->Timestamp;

  /* BusAssignment: '<S12>/Bus Assignment' */
  rtb_BusAssignment.ID = rtu_canMsg->ID;
  rtb_BusAssignment.Length = rtu_canMsg->Length;
  for (i = 0; i < 8; i++) {
    uint8_T rtu_canMsg_0;
    rtu_canMsg_0 = rtu_canMsg->Data[i];
    rtb_BusAssignment.Data[i] = rtu_canMsg_0;
  }

  rtb_BusAssignment.Extended = rtu_canMsg->Extended;
  rtb_BusAssignment.Remote = rtu_canMsg->Remote;
  rtb_BusAssignment.Error = rtu_canMsg->Error;
  rtb_BusAssignment.Timestamp = rtb_Cast_h;

  /* End of BusAssignment: '<S12>/Bus Assignment' */

  /* CCaller: '<S12>/CanSendMessage1' incorporates:
   *  Constant: '<S12>/can'
   */
  *rty_result = CanSendMessage(0, &rtb_BusAssignment);
}

/* Model step function */
void simulink_app_step(void)
{
  int32_T i;
  uint8_T rtb_Add;
  boolean_T rtb_RelationalOperator1[8];
  boolean_T rtb_CanSendMessage1_h;
  boolean_T rtb_RelationalOperator3;
  boolean_T rtb_outGreenLed;
  if (stm32f207_template_app_M->Timing.TaskCounters.TID[1] == 0) {
    /* Sum: '<Root>/Add' incorporates:
     *  Constant: '<Root>/Constant8'
     *  Delay: '<Root>/Delay One Step'
     */
    rtb_Add = (uint8_T)((uint32_T)stm32f207_template_app_DW.DelayOneStep_DSTATE
                        + 1U);

    /* SignalConversion generated from: '<Root>/CAN Pack4' incorporates:
     *  Constant: '<Root>/Constant7'
     *  Constant: '<Root>/Constant8'
     *  Delay: '<Root>/Delay One Step'
     *  Sum: '<Root>/Add'
     */
    stm32f207_template_app_DW.TmpSignalConversionAtCANPack4In[0] = MAX_uint8_T;
    stm32f207_template_app_DW.TmpSignalConversionAtCANPack4In[1] = MAX_uint8_T;
    stm32f207_template_app_DW.TmpSignalConversionAtCANPack4In[2] = MAX_uint8_T;
    stm32f207_template_app_DW.TmpSignalConversionAtCANPack4In[3] = MAX_uint8_T;
    stm32f207_template_app_DW.TmpSignalConversionAtCANPack4In[4] = MAX_uint8_T;
    stm32f207_template_app_DW.TmpSignalConversionAtCANPack4In[5] = MAX_uint8_T;
    stm32f207_template_app_DW.TmpSignalConversionAtCANPack4In[6] = MAX_uint8_T;
    stm32f207_template_app_DW.TmpSignalConversionAtCANPack4In[7] = (uint8_T)
      ((uint32_T)stm32f207_template_app_DW.DelayOneStep_DSTATE + 1U);

    /* S-Function (scanpack): '<Root>/CAN Pack4' */
    /* S-Function (scanpack): '<Root>/CAN Pack4' */
    stm32f207_template_app_DW.CANPack4.ID = 418383107U;
    stm32f207_template_app_DW.CANPack4.Length = 8U;
    stm32f207_template_app_DW.CANPack4.Extended = 1U;
    stm32f207_template_app_DW.CANPack4.Remote = 0;
    stm32f207_template_app_DW.CANPack4.Data[0] = 0;
    stm32f207_template_app_DW.CANPack4.Data[1] = 0;
    stm32f207_template_app_DW.CANPack4.Data[2] = 0;
    stm32f207_template_app_DW.CANPack4.Data[3] = 0;
    stm32f207_template_app_DW.CANPack4.Data[4] = 0;
    stm32f207_template_app_DW.CANPack4.Data[5] = 0;
    stm32f207_template_app_DW.CANPack4.Data[6] = 0;
    stm32f207_template_app_DW.CANPack4.Data[7] = 0;

    {
      (void) memcpy((stm32f207_template_app_DW.CANPack4.Data),
                    &stm32f207_template_app_DW.TmpSignalConversionAtCANPack4In[0],
                    8 * sizeof(uint8_T));
    }

    /* Outputs for Atomic SubSystem: '<S6>/CanTxPMsg' */
    /* RelationalOperator: '<S19>/Relational Operator1' incorporates:
     *  Memory: '<S19>/Memory'
     */
    for (i = 0; i < 8; i++) {
      rtb_RelationalOperator1[i] = (stm32f207_template_app_DW.CANPack4.Data[i]
        != stm32f207_template_app_DW.Memory_PreviousInput[i]);
    }

    /* End of RelationalOperator: '<S19>/Relational Operator1' */

    /* Memory: '<S22>/Memory4' */
    stm32f207_template_app_DW.Memory4 =
      stm32f207_template_app_DW.Memory4_PreviousInput;

    /* S-Function (sdspcount2): '<S22>/Counter' incorporates:
     *  Memory: '<S22>/Memory1'
     */
    if (stm32f207_template_app_DW.Memory4) {
      stm32f207_template_app_DW.Counter_Count = 0U;
    }

    if (stm32f207_template_app_DW.Memory1_PreviousInput != 0U) {
      stm32f207_template_app_DW.Counter_Count++;
    }

    /* S-Function (sfix_bitop): '<S19>/Bitwise OR' */
    rtb_CanSendMessage1_h = rtb_RelationalOperator1[0];
    for (i = 0; i < 7; i++) {
      rtb_CanSendMessage1_h = rtb_RelationalOperator1[i + 1] |
        rtb_CanSendMessage1_h;
    }

    /* RelationalOperator: '<S22>/Relational Operator3' incorporates:
     *  Constant: '<S22>/Constant3'
     *  Product: '<S22>/Product'
     *  S-Function (sdspcount2): '<S22>/Counter'
     *  SampleTimeMath: '<S22>/Weighted Sample Time'
     *
     * About '<S22>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_RelationalOperator3 = ((uint32_T)((real32_T)(20.0F * (real32_T)
      stm32f207_template_app_DW.Counter_Count)) >= 500U);

    /* Logic: '<S19>/AND' incorporates:
     *  Logic: '<S19>/OR'
     *  Logic: '<S22>/AND1'
     *  Memory: '<S19>/Memory3'
     *  S-Function (sfix_bitop): '<S19>/Bitwise OR'
     */
    stm32f207_template_app_DW.AND = (boolean_T)((int32_T)
      ((stm32f207_template_app_DW.Memory3_PreviousInput ? ((int32_T)1) :
        ((int32_T)0)) | (rtb_RelationalOperator3 ? ((int32_T)1) : ((int32_T)0))))
      | rtb_CanSendMessage1_h;

    /* S-Function (fcgen): '<S19>/Function-Call Generator' */
    if (stm32f207_template_app_DW.AND) {
      /* Outputs for Function Call SubSystem: '<S19>/CAN send' */
      stm32f207_template_app_CANsend(&stm32f207_template_app_DW.CANPack4,
        &stm32f207_template_app_DW.CanSendMessage1);

      /* End of Outputs for SubSystem: '<S19>/CAN send' */
    }

    /* End of Outputs for S-Function (fcgen): '<S19>/Function-Call Generator' */

    /* Update for Memory: '<S22>/Memory1' incorporates:
     *  Constant: '<S22>/Constant2'
     */
    stm32f207_template_app_DW.Memory1_PreviousInput = 1U;

    /* Update for Memory: '<S22>/Memory4' */
    stm32f207_template_app_DW.Memory4_PreviousInput = rtb_RelationalOperator3;

    /* Update for Memory: '<S19>/Memory3' incorporates:
     *  RelationalOperator: '<S21>/Compare'
     */
    stm32f207_template_app_DW.Memory3_PreviousInput =
      stm32f207_template_app_DW.CanSendMessage1 ^ 1;

    /* Outputs for Atomic SubSystem: '<S4>/CanTxPMsg' */
    for (i = 0; i < 8; i++) {
      /* Update for Memory: '<S19>/Memory' */
      stm32f207_template_app_DW.Memory_PreviousInput[i] =
        stm32f207_template_app_DW.CANPack4.Data[i];

      /* RelationalOperator: '<S11>/Relational Operator1' incorporates:
       *  Memory: '<S11>/Memory'
       */
      rtb_RelationalOperator1[i] = (stm32f207_template_app_ConstB.CANPack.Data[i]
        != stm32f207_template_app_DW.Memory_PreviousInput_c[i]);
    }

    /* End of Outputs for SubSystem: '<S6>/CanTxPMsg' */

    /* Memory: '<S14>/Memory4' */
    stm32f207_template_app_DW.Memory4_o =
      stm32f207_template_app_DW.Memory4_PreviousInput_e;

    /* S-Function (sdspcount2): '<S14>/Counter' incorporates:
     *  Memory: '<S14>/Memory1'
     */
    if (stm32f207_template_app_DW.Memory4_o) {
      stm32f207_template_app_DW.Counter_Count_n = 0U;
    }

    if (stm32f207_template_app_DW.Memory1_PreviousInput_a != 0U) {
      stm32f207_template_app_DW.Counter_Count_n++;
    }

    /* S-Function (sfix_bitop): '<S11>/Bitwise OR' */
    rtb_CanSendMessage1_h = rtb_RelationalOperator1[0];
    for (i = 0; i < 7; i++) {
      rtb_CanSendMessage1_h = rtb_RelationalOperator1[i + 1] |
        rtb_CanSendMessage1_h;
    }

    /* End of S-Function (sfix_bitop): '<S11>/Bitwise OR' */

    /* RelationalOperator: '<S14>/Relational Operator3' incorporates:
     *  Constant: '<S14>/Constant3'
     *  Product: '<S14>/Product'
     *  S-Function (sdspcount2): '<S14>/Counter'
     *  SampleTimeMath: '<S14>/Weighted Sample Time'
     *
     * About '<S14>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_RelationalOperator3 = ((uint32_T)((real32_T)(20.0F * (real32_T)
      stm32f207_template_app_DW.Counter_Count_n)) >= 100U);

    /* Logic: '<S11>/AND' incorporates:
     *  Logic: '<S11>/OR'
     *  Logic: '<S14>/AND1'
     *  Memory: '<S11>/Memory3'
     */
    stm32f207_template_app_DW.AND_l =
      stm32f207_template_app_DW.Memory3_PreviousInput_f |
      rtb_RelationalOperator3;

    /* S-Function (fcgen): '<S11>/Function-Call Generator' */
    if (stm32f207_template_app_DW.AND_l) {
      /* Outputs for Function Call SubSystem: '<S11>/CAN send' */
      stm32f207_template_app_CANsend(&stm32f207_template_app_ConstB.CANPack,
        &stm32f207_template_app_DW.CanSendMessage1_m);

      /* End of Outputs for SubSystem: '<S11>/CAN send' */
    }

    /* End of Outputs for S-Function (fcgen): '<S11>/Function-Call Generator' */

    /* Update for Memory: '<S11>/Memory' */
    for (i = 0; i < 8; i++) {
      stm32f207_template_app_DW.Memory_PreviousInput_c[i] =
        stm32f207_template_app_ConstB.CANPack.Data[i];
    }

    /* End of Update for Memory: '<S11>/Memory' */

    /* Update for Memory: '<S14>/Memory1' incorporates:
     *  Constant: '<S14>/Constant2'
     */
    stm32f207_template_app_DW.Memory1_PreviousInput_a = 1U;

    /* Update for Memory: '<S14>/Memory4' */
    stm32f207_template_app_DW.Memory4_PreviousInput_e = rtb_RelationalOperator3;

    /* Update for Memory: '<S11>/Memory3' incorporates:
     *  RelationalOperator: '<S13>/Compare'
     */
    stm32f207_template_app_DW.Memory3_PreviousInput_f =
      stm32f207_template_app_DW.CanSendMessage1_m ^ 1;

    /* End of Outputs for SubSystem: '<S4>/CanTxPMsg' */
  }

  if (stm32f207_template_app_M->Timing.TaskCounters.TID[3] == 0) {
    /* S-Function (fcgen): '<Root>/Function-Call Generator' incorporates:
     *  SubSystem: '<Root>/�anSendMsg'
     */
    stm32f207_template_ap_anSendMsg(&rtb_CanSendMessage1_h,
      &stm32f207_template_app_ConstB.anSendMsg);

    /* End of Outputs for S-Function (fcgen): '<Root>/Function-Call Generator' */
  }

  if (stm32f207_template_app_M->Timing.TaskCounters.TID[2] == 0) {
    /* S-Function (fcgen): '<Root>/Function-Call Generator1' incorporates:
     *  SubSystem: '<Root>/�anSendMsg1'
     */
    stm32f207_template_ap_anSendMsg(&rtb_CanSendMessage1_h,
      &stm32f207_template_app_ConstB.anSendMsg1);

    /* End of Outputs for S-Function (fcgen): '<Root>/Function-Call Generator1' */
  }

  if (stm32f207_template_app_M->Timing.TaskCounters.TID[1] == 0) {
    /* Outputs for Atomic SubSystem: '<S5>/CanTxPMsg' */
    /* Memory: '<S18>/Memory4' */
    stm32f207_template_app_DW.Memory4_g =
      stm32f207_template_app_DW.Memory4_PreviousInput_m;

    /* S-Function (sdspcount2): '<S18>/Counter' incorporates:
     *  Memory: '<S18>/Memory1'
     */
    if (stm32f207_template_app_DW.Memory4_g) {
      stm32f207_template_app_DW.Counter_Count_k = 0U;
    }

    if (stm32f207_template_app_DW.Memory1_PreviousInput_h != 0U) {
      stm32f207_template_app_DW.Counter_Count_k++;
    }

    /* RelationalOperator: '<S18>/Relational Operator3' incorporates:
     *  Constant: '<S18>/Constant3'
     *  Product: '<S18>/Product'
     *  S-Function (sdspcount2): '<S18>/Counter'
     *  SampleTimeMath: '<S18>/Weighted Sample Time'
     *
     * About '<S18>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_RelationalOperator3 = ((uint32_T)((real32_T)(20.0F * (real32_T)
      stm32f207_template_app_DW.Counter_Count_k)) >= 250U);

    /* Logic: '<S15>/AND' incorporates:
     *  Logic: '<S15>/OR'
     *  Logic: '<S18>/AND1'
     *  Memory: '<S15>/Memory3'
     */
    stm32f207_template_app_DW.AND_d =
      stm32f207_template_app_DW.Memory3_PreviousInput_j |
      rtb_RelationalOperator3;

    /* S-Function (fcgen): '<S15>/Function-Call Generator' */
    if (stm32f207_template_app_DW.AND_d) {
      /* Outputs for Function Call SubSystem: '<S15>/CAN send' */
      stm32f207_template_app_CANsend(&stm32f207_template_app_ConstB.CANPack3,
        &stm32f207_template_app_DW.CanSendMessage1_a);

      /* End of Outputs for SubSystem: '<S15>/CAN send' */
    }

    /* End of Outputs for S-Function (fcgen): '<S15>/Function-Call Generator' */

    /* Update for Memory: '<S15>/Memory' */
    for (i = 0; i < 8; i++) {
      stm32f207_template_app_DW.Memory_PreviousInput_d[i] =
        stm32f207_template_app_ConstB.CANPack3.Data[i];
    }

    /* End of Update for Memory: '<S15>/Memory' */

    /* Update for Memory: '<S18>/Memory1' incorporates:
     *  Constant: '<S18>/Constant2'
     */
    stm32f207_template_app_DW.Memory1_PreviousInput_h = 1U;

    /* Update for Memory: '<S18>/Memory4' */
    stm32f207_template_app_DW.Memory4_PreviousInput_m = rtb_RelationalOperator3;

    /* Update for Memory: '<S15>/Memory3' incorporates:
     *  RelationalOperator: '<S17>/Compare'
     */
    stm32f207_template_app_DW.Memory3_PreviousInput_j =
      stm32f207_template_app_DW.CanSendMessage1_a ^ 1;

    /* End of Outputs for SubSystem: '<S5>/CanTxPMsg' */

    /* Outputs for Atomic SubSystem: '<Root>/MainLogic' */
    /* Chart: '<S1>/Chart' */
    /* Gateway: MainLogic/Chart */
    if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i1 < 15U) {
      stm32f207_template_app_DW.temporalCounter_i1 = (uint8_T)((uint32_T)
        stm32f207_template_app_DW.temporalCounter_i1 + 1U);
    }

    if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i2 < 31U) {
      stm32f207_template_app_DW.temporalCounter_i2 = (uint8_T)((uint32_T)
        stm32f207_template_app_DW.temporalCounter_i2 + 1U);
    }

    if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i3 < 63U) {
      stm32f207_template_app_DW.temporalCounter_i3 = (uint8_T)((uint32_T)
        stm32f207_template_app_DW.temporalCounter_i3 + 1U);
    }

    /* During: MainLogic/Chart */
    if ((uint32_T)stm32f207_template_app_DW.is_active_c3_stm32f207_template ==
        0U) {
      /* Entry: MainLogic/Chart */
      stm32f207_template_app_DW.is_active_c3_stm32f207_template = 1U;

      /* Entry Internal: MainLogic/Chart */
      /* Entry Internal 'RED_LED': '<S7>:25' */
      /* Transition: '<S7>:27' */
      stm32f207_template_app_DW.temporalCounter_i1 = 0U;
      stm32f207_template_app_DW.is_RED_LED = stm32f207_template_app_IN_OFF;

      /* Entry 'OFF': '<S7>:21' */
      /* '<S7>:21:3' outRedLed = true; */
      rtb_CanSendMessage1_h = true;

      /* Entry Internal 'BLUE_LED': '<S7>:26' */
      /* Transition: '<S7>:28' */
      stm32f207_template_app_DW.temporalCounter_i2 = 0U;
      stm32f207_template_app_DW.is_BLUE_LED = stm32f207_template_app_IN_OFF;

      /* Entry 'OFF': '<S7>:7' */
      /* '<S7>:7:3' outBlueLed = true; */
      rtb_RelationalOperator3 = true;

      /* Entry Internal 'GREEN_LED': '<S7>:29' */
      /* Transition: '<S7>:32' */
      stm32f207_template_app_DW.temporalCounter_i3 = 0U;
      stm32f207_template_app_DW.is_GREEN_LED = stm32f207_template_app_IN_OFF;

      /* Entry 'OFF': '<S7>:12' */
      /* '<S7>:12:3' outGreenLed = true; */
      rtb_outGreenLed = true;
    } else {
      /* During 'RED_LED': '<S7>:25' */
      if ((uint32_T)stm32f207_template_app_DW.is_RED_LED ==
          stm32f207_template_app_IN_OFF) {
        rtb_CanSendMessage1_h = true;

        /* During 'OFF': '<S7>:21' */
        /* '<S7>:24:1' sf_internal_predicateOutput = after(100, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i1 >= 5U) {
          /* Transition: '<S7>:24' */
          stm32f207_template_app_DW.temporalCounter_i1 = 0U;
          stm32f207_template_app_DW.is_RED_LED = stm32f207_template_app_IN_ON;

          /* Entry 'ON': '<S7>:22' */
          /* '<S7>:22:3' outRedLed = false; */
          rtb_CanSendMessage1_h = false;
        }
      } else {
        rtb_CanSendMessage1_h = false;

        /* During 'ON': '<S7>:22' */
        /* '<S7>:23:1' sf_internal_predicateOutput = after(250, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i1 >= 13U) {
          /* Transition: '<S7>:23' */
          stm32f207_template_app_DW.temporalCounter_i1 = 0U;
          stm32f207_template_app_DW.is_RED_LED = stm32f207_template_app_IN_OFF;

          /* Entry 'OFF': '<S7>:21' */
          /* '<S7>:21:3' outRedLed = true; */
          rtb_CanSendMessage1_h = true;
        }
      }

      /* During 'BLUE_LED': '<S7>:26' */
      if ((uint32_T)stm32f207_template_app_DW.is_BLUE_LED ==
          stm32f207_template_app_IN_OFF) {
        rtb_RelationalOperator3 = true;

        /* During 'OFF': '<S7>:7' */
        /* '<S7>:10:1' sf_internal_predicateOutput = after(500, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i2 >= 25U) {
          /* Transition: '<S7>:10' */
          stm32f207_template_app_DW.temporalCounter_i2 = 0U;
          stm32f207_template_app_DW.is_BLUE_LED = stm32f207_template_app_IN_ON;

          /* Entry 'ON': '<S7>:8' */
          /* '<S7>:8:3' outBlueLed = false; */
          rtb_RelationalOperator3 = false;
        }
      } else {
        rtb_RelationalOperator3 = false;

        /* During 'ON': '<S7>:8' */
        /* '<S7>:9:1' sf_internal_predicateOutput = after(500, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i2 >= 25U) {
          /* Transition: '<S7>:9' */
          stm32f207_template_app_DW.temporalCounter_i2 = 0U;
          stm32f207_template_app_DW.is_BLUE_LED = stm32f207_template_app_IN_OFF;

          /* Entry 'OFF': '<S7>:7' */
          /* '<S7>:7:3' outBlueLed = true; */
          rtb_RelationalOperator3 = true;
        }
      }

      /* During 'GREEN_LED': '<S7>:29' */
      if ((uint32_T)stm32f207_template_app_DW.is_GREEN_LED ==
          stm32f207_template_app_IN_OFF) {
        rtb_outGreenLed = true;

        /* During 'OFF': '<S7>:12' */
        /* '<S7>:15:1' sf_internal_predicateOutput = after(1000, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i3 >= 50U) {
          /* Transition: '<S7>:15' */
          stm32f207_template_app_DW.temporalCounter_i3 = 0U;
          stm32f207_template_app_DW.is_GREEN_LED = stm32f207_template_app_IN_ON;

          /* Entry 'ON': '<S7>:13' */
          /* '<S7>:13:3' outGreenLed = false; */
          rtb_outGreenLed = false;
        }
      } else {
        rtb_outGreenLed = false;

        /* During 'ON': '<S7>:13' */
        /* '<S7>:14:1' sf_internal_predicateOutput = after(1000, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i3 >= 50U) {
          /* Transition: '<S7>:14' */
          stm32f207_template_app_DW.temporalCounter_i3 = 0U;
          stm32f207_template_app_DW.is_GREEN_LED = stm32f207_template_app_IN_OFF;

          /* Entry 'OFF': '<S7>:12' */
          /* '<S7>:12:3' outGreenLed = true; */
          rtb_outGreenLed = true;
        }
      }
    }

    /* End of Chart: '<S1>/Chart' */

    /* Logic: '<S1>/AND2' incorporates:
     *  Constant: '<S1>/Constant'
     */
    stm32f207_template_app_DW.BlueSts = BlueSwitch & rtb_RelationalOperator3;

    /* CCaller: '<S8>/SetLedState1' incorporates:
     *  Constant: '<S8>/Constant'
     *  DataTypeConversion: '<S8>/Cast'
     */
    SetLedState((uint8_T)2U, (uint8_T)stm32f207_template_app_DW.BlueSts);

    /* Logic: '<S1>/AND1' incorporates:
     *  Constant: '<S1>/Constant1'
     */
    stm32f207_template_app_DW.GreenSts = GreenSwitch & rtb_outGreenLed;

    /* CCaller: '<S9>/SetLedState1' incorporates:
     *  Constant: '<S9>/Constant'
     *  DataTypeConversion: '<S9>/Cast'
     */
    SetLedState((uint8_T)1U, (uint8_T)stm32f207_template_app_DW.GreenSts);

    /* Logic: '<S1>/AND' incorporates:
     *  Constant: '<S1>/Constant2'
     */
    stm32f207_template_app_DW.RedSts = RedSwitch & rtb_CanSendMessage1_h;

    /* CCaller: '<S10>/SetLedState1' incorporates:
     *  Constant: '<S10>/Constant'
     *  DataTypeConversion: '<S10>/Cast'
     */
    SetLedState((uint8_T)3U, (uint8_T)stm32f207_template_app_DW.RedSts);

    /* End of Outputs for SubSystem: '<Root>/MainLogic' */

    /* Update for Delay: '<Root>/Delay One Step' */
    stm32f207_template_app_DW.DelayOneStep_DSTATE = rtb_Add;
  }

  rate_scheduler();
}

/* Model initialize function */
void simulink_app_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void simulink_app_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
