/*
 * File: simulink_app.c
 *
 * Code generated for Simulink model 'stm32f207_template_app'.
 *
 * Model version                  : 1.567
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Sun Jul  6 11:54:19 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. MISRA C:2012 guidelines
 *    2. Execution efficiency
 *    3. ROM efficiency
 *    4. RAM efficiency
 *    5. Traceability
 *    6. Safety precaution
 *    7. Debugging
 * Validation result: Not run
 */

#include "simulink_app.h"
#include "simulink_apptypes.h"
#include "rtwtypes.h"
#include "simulink_appprivate.h"
#include "can_control.h"

/* Named constants for Chart: '<S2>/Chart' */
#define stm32f207_template_app_IN_OFF  ((uint8_T)1U)
#define stm32f207_template_app_IN_ON   ((uint8_T)2U)

/* Exported data definition */

/* Volatile memory section */
/* Definition for custom storage class: Volatile */
volatile boolean_T BlueSwitch = true;  /* Referenced by: '<S2>/Constant' */
volatile boolean_T GreenSwitch = false;/* Referenced by: '<S2>/Constant1' */
volatile boolean_T RedSwitch = true;   /* Referenced by: '<S2>/Constant2' */

/* Block signals and states (default storage) */
DW_stm32f207_template_app_T stm32f207_template_app_DW;

/* Real-time model */
static RT_MODEL_stm32f207_template_a_T stm32f207_template_app_M_;
RT_MODEL_stm32f207_template_a_T *const stm32f207_template_app_M =
  &stm32f207_template_app_M_;
static void rate_scheduler(void);

/*
 *         This function updates active task flag for each subrate.
 *         The function is called at model base rate, hence the
 *         generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (stm32f207_template_app_M->Timing.TaskCounters.TID[1])++;
  if ((stm32f207_template_app_M->Timing.TaskCounters.TID[1]) > 1) {/* Sample time: [0.02s, 0.0s] */
    stm32f207_template_app_M->Timing.TaskCounters.TID[1] = 0;
  }

  (stm32f207_template_app_M->Timing.TaskCounters.TID[2])++;
  if ((stm32f207_template_app_M->Timing.TaskCounters.TID[2]) > 49) {/* Sample time: [0.5s, 0.0s] */
    stm32f207_template_app_M->Timing.TaskCounters.TID[2] = 0;
  }

  (stm32f207_template_app_M->Timing.TaskCounters.TID[3])++;
  if ((stm32f207_template_app_M->Timing.TaskCounters.TID[3]) > 99) {/* Sample time: [1.0s, 0.0s] */
    stm32f207_template_app_M->Timing.TaskCounters.TID[3] = 0;
  }
}

/*
 * Output and update for function-call system:
 *    '<S1>/�anSendMsg'
 *    '<S1>/�anSendMsg1'
 */
void stm32f207_template_ap_anSendMsg(const CAN_MESSAGE_BUS *rtu_canMsg,
  boolean_T *rty_result)
{
  CAN_Msg_t rtb_BusAssignment;
  int32_T i;

  /* DataTypeConversion: '<S3>/Cast' */
  rtb_BusAssignment.Timestamp = (uint32_T)rtu_canMsg->Timestamp;

  /* BusAssignment: '<S3>/Bus Assignment' */
  rtb_BusAssignment.ID = rtu_canMsg->ID;
  rtb_BusAssignment.Length = rtu_canMsg->Length;
  for (i = 0; i < 8; i++) {
    uint8_T rtu_canMsg_0;
    rtu_canMsg_0 = rtu_canMsg->Data[i];
    rtb_BusAssignment.Data[i] = rtu_canMsg_0;
  }

  rtb_BusAssignment.Extended = rtu_canMsg->Extended;
  rtb_BusAssignment.Remote = rtu_canMsg->Remote;
  rtb_BusAssignment.Error = rtu_canMsg->Error;

  /* End of BusAssignment: '<S3>/Bus Assignment' */

  /* CCaller: '<S3>/CanSendMessage1' incorporates:
   *  Constant: '<S3>/can'
   */
  *rty_result = CanSendMessage(0, &rtb_BusAssignment);
}

/*
 * Output and update for function-call system:
 *    '<S8>/CAN send'
 *    '<S12>/CAN send'
 *    '<S16>/CAN send'
 */
void stm32f207_template_app_CANsend(const CAN_MESSAGE_BUS *rtu_canMsg, boolean_T
  *rty_result)
{
  CAN_Msg_t rtb_BusAssignment;
  int32_T i;
  uint32_T rtb_Cast_h;

  /* DataTypeConversion: '<S9>/Cast' */
  rtb_Cast_h = (uint32_T)rtu_canMsg->Timestamp;

  /* BusAssignment: '<S9>/Bus Assignment' */
  rtb_BusAssignment.ID = rtu_canMsg->ID;
  rtb_BusAssignment.Length = rtu_canMsg->Length;
  for (i = 0; i < 8; i++) {
    uint8_T rtu_canMsg_0;
    rtu_canMsg_0 = rtu_canMsg->Data[i];
    rtb_BusAssignment.Data[i] = rtu_canMsg_0;
  }

  rtb_BusAssignment.Extended = rtu_canMsg->Extended;
  rtb_BusAssignment.Remote = rtu_canMsg->Remote;
  rtb_BusAssignment.Error = rtu_canMsg->Error;
  rtb_BusAssignment.Timestamp = rtb_Cast_h;

  /* End of BusAssignment: '<S9>/Bus Assignment' */

  /* CCaller: '<S9>/CanSendMessage1' incorporates:
   *  Constant: '<S9>/can'
   */
  *rty_result = CanSendMessage(0, &rtb_BusAssignment);
}

/* Model step function */
void simulink_app_step(void)
{
  int32_T i;
  uint8_T rtb_Add;
  boolean_T rtb_RelationalOperator1_c[8];
  boolean_T rtb_outBlueLed;
  boolean_T rtb_outGreenLed;
  boolean_T rtb_outRedLed;
  if (stm32f207_template_app_M->Timing.TaskCounters.TID[1] == 0) {
    /* Outputs for Atomic SubSystem: '<Root>/MainLogic' */
    /* Sum: '<S2>/Add' incorporates:
     *  Constant: '<S2>/Constant11'
     *  Delay: '<S2>/Delay One Step'
     */
    rtb_Add = (uint8_T)((uint32_T)stm32f207_template_app_DW.DelayOneStep_DSTATE
                        + 1U);

    /* Chart: '<S2>/Chart' */
    /* Gateway: MainLogic/Chart */
    if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i1 < 15U) {
      stm32f207_template_app_DW.temporalCounter_i1 = (uint8_T)((uint32_T)
        stm32f207_template_app_DW.temporalCounter_i1 + 1U);
    }

    if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i2 < 31U) {
      stm32f207_template_app_DW.temporalCounter_i2 = (uint8_T)((uint32_T)
        stm32f207_template_app_DW.temporalCounter_i2 + 1U);
    }

    if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i3 < 63U) {
      stm32f207_template_app_DW.temporalCounter_i3 = (uint8_T)((uint32_T)
        stm32f207_template_app_DW.temporalCounter_i3 + 1U);
    }

    /* During: MainLogic/Chart */
    if ((uint32_T)stm32f207_template_app_DW.is_active_c3_stm32f207_template ==
        0U) {
      /* Entry: MainLogic/Chart */
      stm32f207_template_app_DW.is_active_c3_stm32f207_template = 1U;

      /* Entry Internal: MainLogic/Chart */
      /* Entry Internal 'RED_LED': '<S20>:25' */
      /* Transition: '<S20>:27' */
      stm32f207_template_app_DW.temporalCounter_i1 = 0U;
      stm32f207_template_app_DW.is_RED_LED = stm32f207_template_app_IN_OFF;

      /* Entry 'OFF': '<S20>:21' */
      /* '<S20>:21:3' outRedLed = true; */
      rtb_outRedLed = true;

      /* Entry Internal 'BLUE_LED': '<S20>:26' */
      /* Transition: '<S20>:28' */
      stm32f207_template_app_DW.temporalCounter_i2 = 0U;
      stm32f207_template_app_DW.is_BLUE_LED = stm32f207_template_app_IN_OFF;

      /* Entry 'OFF': '<S20>:7' */
      /* '<S20>:7:3' outBlueLed = true; */
      rtb_outBlueLed = true;

      /* Entry Internal 'GREEN_LED': '<S20>:29' */
      /* Transition: '<S20>:32' */
      stm32f207_template_app_DW.temporalCounter_i3 = 0U;
      stm32f207_template_app_DW.is_GREEN_LED = stm32f207_template_app_IN_OFF;

      /* Entry 'OFF': '<S20>:12' */
      /* '<S20>:12:3' outGreenLed = true; */
      rtb_outGreenLed = true;
    } else {
      /* During 'RED_LED': '<S20>:25' */
      if ((uint32_T)stm32f207_template_app_DW.is_RED_LED ==
          stm32f207_template_app_IN_OFF) {
        rtb_outRedLed = true;

        /* During 'OFF': '<S20>:21' */
        /* '<S20>:24:1' sf_internal_predicateOutput = after(100, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i1 >= 5U) {
          /* Transition: '<S20>:24' */
          stm32f207_template_app_DW.temporalCounter_i1 = 0U;
          stm32f207_template_app_DW.is_RED_LED = stm32f207_template_app_IN_ON;

          /* Entry 'ON': '<S20>:22' */
          /* '<S20>:22:3' outRedLed = false; */
          rtb_outRedLed = false;
        }
      } else {
        rtb_outRedLed = false;

        /* During 'ON': '<S20>:22' */
        /* '<S20>:23:1' sf_internal_predicateOutput = after(250, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i1 >= 13U) {
          /* Transition: '<S20>:23' */
          stm32f207_template_app_DW.temporalCounter_i1 = 0U;
          stm32f207_template_app_DW.is_RED_LED = stm32f207_template_app_IN_OFF;

          /* Entry 'OFF': '<S20>:21' */
          /* '<S20>:21:3' outRedLed = true; */
          rtb_outRedLed = true;
        }
      }

      /* During 'BLUE_LED': '<S20>:26' */
      if ((uint32_T)stm32f207_template_app_DW.is_BLUE_LED ==
          stm32f207_template_app_IN_OFF) {
        rtb_outBlueLed = true;

        /* During 'OFF': '<S20>:7' */
        /* '<S20>:10:1' sf_internal_predicateOutput = after(500, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i2 >= 25U) {
          /* Transition: '<S20>:10' */
          stm32f207_template_app_DW.temporalCounter_i2 = 0U;
          stm32f207_template_app_DW.is_BLUE_LED = stm32f207_template_app_IN_ON;

          /* Entry 'ON': '<S20>:8' */
          /* '<S20>:8:3' outBlueLed = false; */
          rtb_outBlueLed = false;
        }
      } else {
        rtb_outBlueLed = false;

        /* During 'ON': '<S20>:8' */
        /* '<S20>:9:1' sf_internal_predicateOutput = after(500, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i2 >= 25U) {
          /* Transition: '<S20>:9' */
          stm32f207_template_app_DW.temporalCounter_i2 = 0U;
          stm32f207_template_app_DW.is_BLUE_LED = stm32f207_template_app_IN_OFF;

          /* Entry 'OFF': '<S20>:7' */
          /* '<S20>:7:3' outBlueLed = true; */
          rtb_outBlueLed = true;
        }
      }

      /* During 'GREEN_LED': '<S20>:29' */
      if ((uint32_T)stm32f207_template_app_DW.is_GREEN_LED ==
          stm32f207_template_app_IN_OFF) {
        rtb_outGreenLed = true;

        /* During 'OFF': '<S20>:12' */
        /* '<S20>:15:1' sf_internal_predicateOutput = after(1000, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i3 >= 50U) {
          /* Transition: '<S20>:15' */
          stm32f207_template_app_DW.temporalCounter_i3 = 0U;
          stm32f207_template_app_DW.is_GREEN_LED = stm32f207_template_app_IN_ON;

          /* Entry 'ON': '<S20>:13' */
          /* '<S20>:13:3' outGreenLed = false; */
          rtb_outGreenLed = false;
        }
      } else {
        rtb_outGreenLed = false;

        /* During 'ON': '<S20>:13' */
        /* '<S20>:14:1' sf_internal_predicateOutput = after(1000, msec); */
        if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i3 >= 50U) {
          /* Transition: '<S20>:14' */
          stm32f207_template_app_DW.temporalCounter_i3 = 0U;
          stm32f207_template_app_DW.is_GREEN_LED = stm32f207_template_app_IN_OFF;

          /* Entry 'OFF': '<S20>:12' */
          /* '<S20>:12:3' outGreenLed = true; */
          rtb_outGreenLed = true;
        }
      }
    }

    /* End of Chart: '<S2>/Chart' */

    /* Logic: '<S2>/AND2' incorporates:
     *  Constant: '<S2>/Constant'
     */
    stm32f207_template_app_DW.BlueSts = BlueSwitch & rtb_outBlueLed;

    /* CCaller: '<S21>/SetLedState1' incorporates:
     *  Constant: '<S21>/Constant'
     *  DataTypeConversion: '<S21>/Cast'
     */
    SetLedState((uint8_T)2U, (uint8_T)stm32f207_template_app_DW.BlueSts);

    /* Logic: '<S2>/AND1' incorporates:
     *  Constant: '<S2>/Constant1'
     */
    stm32f207_template_app_DW.GreenSts = GreenSwitch & rtb_outGreenLed;

    /* CCaller: '<S22>/SetLedState1' incorporates:
     *  Constant: '<S22>/Constant'
     *  DataTypeConversion: '<S22>/Cast'
     */
    SetLedState((uint8_T)1U, (uint8_T)stm32f207_template_app_DW.GreenSts);

    /* Logic: '<S2>/AND' incorporates:
     *  Constant: '<S2>/Constant2'
     */
    stm32f207_template_app_DW.RedSts = RedSwitch & rtb_outRedLed;

    /* CCaller: '<S23>/SetLedState1' incorporates:
     *  Constant: '<S23>/Constant'
     *  DataTypeConversion: '<S23>/Cast'
     */
    SetLedState((uint8_T)3U, (uint8_T)stm32f207_template_app_DW.RedSts);

    /* Update for Delay: '<S2>/Delay One Step' */
    stm32f207_template_app_DW.DelayOneStep_DSTATE = rtb_Add;

    /* End of Outputs for SubSystem: '<Root>/MainLogic' */

    /* Outputs for Atomic SubSystem: '<Root>/CanTx' */
    /* Outputs for Atomic SubSystem: '<S5>/CanTxPMsg' */
    /* Memory: '<S11>/Memory4' */
    stm32f207_template_app_DW.Memory4_o =
      stm32f207_template_app_DW.Memory4_PreviousInput_e;

    /* S-Function (sdspcount2): '<S11>/Counter' incorporates:
     *  Memory: '<S11>/Memory1'
     */
    if (stm32f207_template_app_DW.Memory4_o) {
      stm32f207_template_app_DW.Counter_Count_n = 0U;
    }

    if (stm32f207_template_app_DW.Memory1_PreviousInput_a != 0U) {
      stm32f207_template_app_DW.Counter_Count_n++;
    }

    /* RelationalOperator: '<S11>/Relational Operator3' incorporates:
     *  Constant: '<S11>/Constant3'
     *  Product: '<S11>/Product'
     *  S-Function (sdspcount2): '<S11>/Counter'
     *  SampleTimeMath: '<S11>/Weighted Sample Time'
     *
     * About '<S11>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_outBlueLed = ((uint32_T)((real32_T)(20.0F * (real32_T)
      stm32f207_template_app_DW.Counter_Count_n)) >= 100U);

    /* Logic: '<S8>/AND' incorporates:
     *  Logic: '<S11>/AND1'
     *  Logic: '<S8>/OR'
     *  Memory: '<S8>/Memory3'
     */
    stm32f207_template_app_DW.AND_l =
      stm32f207_template_app_DW.Memory3_PreviousInput_f | rtb_outBlueLed;

    /* S-Function (fcgen): '<S8>/Function-Call Generator' */
    if (stm32f207_template_app_DW.AND_l) {
      /* Outputs for Function Call SubSystem: '<S8>/CAN send' */
      stm32f207_template_app_CANsend(&stm32f207_template_app_ConstB.CANPack,
        &stm32f207_template_app_DW.CanSendMessage1_m);

      /* End of Outputs for SubSystem: '<S8>/CAN send' */
    }

    /* End of Outputs for S-Function (fcgen): '<S8>/Function-Call Generator' */

    /* Update for Memory: '<S8>/Memory' */
    for (i = 0; i < 8; i++) {
      stm32f207_template_app_DW.Memory_PreviousInput_c[i] =
        stm32f207_template_app_ConstB.CANPack.Data[i];
    }

    /* End of Update for Memory: '<S8>/Memory' */

    /* Update for Memory: '<S11>/Memory1' incorporates:
     *  Constant: '<S11>/Constant2'
     */
    stm32f207_template_app_DW.Memory1_PreviousInput_a = 1U;

    /* Update for Memory: '<S11>/Memory4' */
    stm32f207_template_app_DW.Memory4_PreviousInput_e = rtb_outBlueLed;

    /* Update for Memory: '<S8>/Memory3' incorporates:
     *  RelationalOperator: '<S10>/Compare'
     */
    stm32f207_template_app_DW.Memory3_PreviousInput_f =
      stm32f207_template_app_DW.CanSendMessage1_m ^ 1;

    /* End of Outputs for SubSystem: '<S5>/CanTxPMsg' */
    /* End of Outputs for SubSystem: '<Root>/CanTx' */
  }

  /* Outputs for Atomic SubSystem: '<Root>/CanTx' */
  /* Outputs for Atomic SubSystem: '<S6>/CanTxPMsg' */
  /* RelationalOperator: '<S12>/Relational Operator1' incorporates:
   *  Memory: '<S12>/Memory'
   */
  for (i = 0; i < 8; i++) {
    rtb_RelationalOperator1_c[i] =
      (stm32f207_template_app_ConstB.CANPack3.Data[i] !=
       stm32f207_template_app_DW.Memory_PreviousInput_d[i]);
  }

  /* End of RelationalOperator: '<S12>/Relational Operator1' */

  /* Memory: '<S15>/Memory4' */
  stm32f207_template_app_DW.Memory4_g =
    stm32f207_template_app_DW.Memory4_PreviousInput_m;

  /* S-Function (sdspcount2): '<S15>/Counter' incorporates:
   *  Memory: '<S15>/Memory1'
   */
  if (stm32f207_template_app_DW.Memory4_g) {
    stm32f207_template_app_DW.Counter_Count_k = 0U;
  }

  if (stm32f207_template_app_DW.Memory1_PreviousInput_h != 0U) {
    stm32f207_template_app_DW.Counter_Count_k++;
  }

  /* S-Function (sfix_bitop): '<S12>/Bitwise OR' */
  rtb_outRedLed = rtb_RelationalOperator1_c[0];
  for (i = 0; i < 7; i++) {
    rtb_outRedLed = rtb_RelationalOperator1_c[i + 1] | rtb_outRedLed;
  }

  /* End of S-Function (sfix_bitop): '<S12>/Bitwise OR' */

  /* RelationalOperator: '<S15>/Relational Operator3' incorporates:
   *  Constant: '<S15>/Constant3'
   *  Product: '<S15>/Product'
   *  S-Function (sdspcount2): '<S15>/Counter'
   *  SampleTimeMath: '<S15>/Weighted Sample Time'
   *
   * About '<S15>/Weighted Sample Time':
   *  y = K where K = ( w * Ts )
   */
  rtb_outBlueLed = ((uint32_T)((real32_T)(10.0F * (real32_T)
    stm32f207_template_app_DW.Counter_Count_k)) >= 250U);

  /* Logic: '<S12>/AND' incorporates:
   *  Logic: '<S12>/OR'
   *  Logic: '<S15>/AND1'
   *  Memory: '<S12>/Memory3'
   */
  stm32f207_template_app_DW.AND_d =
    stm32f207_template_app_DW.Memory3_PreviousInput_j | rtb_outBlueLed;

  /* S-Function (fcgen): '<S12>/Function-Call Generator' */
  if (stm32f207_template_app_DW.AND_d) {
    /* Outputs for Function Call SubSystem: '<S12>/CAN send' */
    stm32f207_template_app_CANsend(&stm32f207_template_app_ConstB.CANPack3,
      &stm32f207_template_app_DW.CanSendMessage1_a);

    /* End of Outputs for SubSystem: '<S12>/CAN send' */
  }

  /* End of Outputs for S-Function (fcgen): '<S12>/Function-Call Generator' */

  /* Update for Memory: '<S12>/Memory' */
  for (i = 0; i < 8; i++) {
    stm32f207_template_app_DW.Memory_PreviousInput_d[i] =
      stm32f207_template_app_ConstB.CANPack3.Data[i];
  }

  /* End of Update for Memory: '<S12>/Memory' */

  /* Update for Memory: '<S15>/Memory1' incorporates:
   *  Constant: '<S15>/Constant2'
   */
  stm32f207_template_app_DW.Memory1_PreviousInput_h = 1U;

  /* Update for Memory: '<S15>/Memory4' */
  stm32f207_template_app_DW.Memory4_PreviousInput_m = rtb_outBlueLed;

  /* Update for Memory: '<S12>/Memory3' incorporates:
   *  RelationalOperator: '<S14>/Compare'
   */
  stm32f207_template_app_DW.Memory3_PreviousInput_j =
    stm32f207_template_app_DW.CanSendMessage1_a ^ 1;

  /* End of Outputs for SubSystem: '<S6>/CanTxPMsg' */
  if (stm32f207_template_app_M->Timing.TaskCounters.TID[1] == 0) {
    /* SignalConversion generated from: '<S1>/CAN Pack4' incorporates:
     *  Constant: '<S2>/Constant10'
     */
    stm32f207_template_app_DW.Data[0] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[1] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[2] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[3] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[4] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[5] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[6] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[7] = rtb_Add;

    /* S-Function (scanpack): '<S1>/CAN Pack4' */
    /* S-Function (scanpack): '<S1>/CAN Pack4' */
    stm32f207_template_app_DW.CANPack4.ID = 418383107U;
    stm32f207_template_app_DW.CANPack4.Length = 8U;
    stm32f207_template_app_DW.CANPack4.Extended = 1U;
    stm32f207_template_app_DW.CANPack4.Remote = 0;
    stm32f207_template_app_DW.CANPack4.Data[0] = 0;
    stm32f207_template_app_DW.CANPack4.Data[1] = 0;
    stm32f207_template_app_DW.CANPack4.Data[2] = 0;
    stm32f207_template_app_DW.CANPack4.Data[3] = 0;
    stm32f207_template_app_DW.CANPack4.Data[4] = 0;
    stm32f207_template_app_DW.CANPack4.Data[5] = 0;
    stm32f207_template_app_DW.CANPack4.Data[6] = 0;
    stm32f207_template_app_DW.CANPack4.Data[7] = 0;

    {
      (void) memcpy((stm32f207_template_app_DW.CANPack4.Data),
                    &stm32f207_template_app_DW.Data[0],
                    8 * sizeof(uint8_T));
    }

    /* Outputs for Atomic SubSystem: '<S7>/CanTxPMsg' */
    /* RelationalOperator: '<S16>/Relational Operator1' incorporates:
     *  Memory: '<S16>/Memory'
     */
    for (i = 0; i < 8; i++) {
      rtb_RelationalOperator1_c[i] = (stm32f207_template_app_DW.CANPack4.Data[i]
        != stm32f207_template_app_DW.Memory_PreviousInput[i]);
    }

    /* End of RelationalOperator: '<S16>/Relational Operator1' */

    /* Memory: '<S19>/Memory4' */
    stm32f207_template_app_DW.Memory4 =
      stm32f207_template_app_DW.Memory4_PreviousInput;

    /* S-Function (sdspcount2): '<S19>/Counter' incorporates:
     *  Memory: '<S19>/Memory1'
     */
    if (stm32f207_template_app_DW.Memory4) {
      stm32f207_template_app_DW.Counter_Count = 0U;
    }

    if (stm32f207_template_app_DW.Memory1_PreviousInput != 0U) {
      stm32f207_template_app_DW.Counter_Count++;
    }

    /* S-Function (sfix_bitop): '<S16>/Bitwise OR' */
    rtb_outRedLed = rtb_RelationalOperator1_c[0];
    for (i = 0; i < 7; i++) {
      rtb_outRedLed = rtb_RelationalOperator1_c[i + 1] | rtb_outRedLed;
    }

    /* RelationalOperator: '<S19>/Relational Operator3' incorporates:
     *  Constant: '<S19>/Constant3'
     *  Product: '<S19>/Product'
     *  S-Function (sdspcount2): '<S19>/Counter'
     *  SampleTimeMath: '<S19>/Weighted Sample Time'
     *
     * About '<S19>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_outBlueLed = ((uint32_T)((real32_T)(20.0F * (real32_T)
      stm32f207_template_app_DW.Counter_Count)) >= 500U);

    /* Logic: '<S16>/AND' incorporates:
     *  Logic: '<S16>/OR'
     *  Logic: '<S19>/AND1'
     *  Memory: '<S16>/Memory3'
     *  S-Function (sfix_bitop): '<S16>/Bitwise OR'
     */
    stm32f207_template_app_DW.AND = (boolean_T)((int32_T)
      ((stm32f207_template_app_DW.Memory3_PreviousInput ? ((int32_T)1) :
        ((int32_T)0)) | (rtb_outBlueLed ? ((int32_T)1) : ((int32_T)0)))) |
      rtb_outRedLed;

    /* S-Function (fcgen): '<S16>/Function-Call Generator' */
    if (stm32f207_template_app_DW.AND) {
      /* Outputs for Function Call SubSystem: '<S16>/CAN send' */
      stm32f207_template_app_CANsend(&stm32f207_template_app_DW.CANPack4,
        &stm32f207_template_app_DW.CanSendMessage1);

      /* End of Outputs for SubSystem: '<S16>/CAN send' */
    }

    /* End of Outputs for S-Function (fcgen): '<S16>/Function-Call Generator' */

    /* Update for Memory: '<S16>/Memory' */
    for (i = 0; i < 8; i++) {
      stm32f207_template_app_DW.Memory_PreviousInput[i] =
        stm32f207_template_app_DW.CANPack4.Data[i];
    }

    /* End of Update for Memory: '<S16>/Memory' */

    /* Update for Memory: '<S19>/Memory1' incorporates:
     *  Constant: '<S19>/Constant2'
     */
    stm32f207_template_app_DW.Memory1_PreviousInput = 1U;

    /* Update for Memory: '<S19>/Memory4' */
    stm32f207_template_app_DW.Memory4_PreviousInput = rtb_outBlueLed;

    /* Update for Memory: '<S16>/Memory3' incorporates:
     *  RelationalOperator: '<S18>/Compare'
     */
    stm32f207_template_app_DW.Memory3_PreviousInput =
      stm32f207_template_app_DW.CanSendMessage1 ^ 1;

    /* End of Outputs for SubSystem: '<S7>/CanTxPMsg' */
  }

  if (stm32f207_template_app_M->Timing.TaskCounters.TID[3] == 0) {
    /* S-Function (fcgen): '<S1>/Function-Call Generator' incorporates:
     *  SubSystem: '<S1>/�anSendMsg'
     */
    stm32f207_template_ap_anSendMsg(&stm32f207_template_app_ConstB.CANPack1,
      &rtb_outRedLed);

    /* End of Outputs for S-Function (fcgen): '<S1>/Function-Call Generator' */
  }

  if (stm32f207_template_app_M->Timing.TaskCounters.TID[2] == 0) {
    /* S-Function (fcgen): '<S1>/Function-Call Generator1' incorporates:
     *  SubSystem: '<S1>/�anSendMsg1'
     */
    stm32f207_template_ap_anSendMsg(&stm32f207_template_app_ConstB.CANPack2,
      &rtb_outRedLed);

    /* End of Outputs for S-Function (fcgen): '<S1>/Function-Call Generator1' */
  }

  /* End of Outputs for SubSystem: '<Root>/CanTx' */
  rate_scheduler();
}

/* Model initialize function */
void simulink_app_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void simulink_app_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
