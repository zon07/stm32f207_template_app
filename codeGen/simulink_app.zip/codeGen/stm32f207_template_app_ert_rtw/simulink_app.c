/*
 * File: simulink_app.c
 *
 * Code generated for Simulink model 'stm32f207_template_app'.
 *
 * Model version                  : 1.592
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Sun Jul  6 14:22:32 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. MISRA C:2012 guidelines
 *    2. Execution efficiency
 *    3. ROM efficiency
 *    4. RAM efficiency
 *    5. Traceability
 *    6. Safety precaution
 *    7. Debugging
 * Validation result: Not run
 */

#include "simulink_app.h"
#include "simulink_apptypes.h"
#include "rtwtypes.h"
#include "simulink_appprivate.h"
#include "can_control.h"

/* Named constants for Chart: '<S3>/Chart' */
#define stm32f207_template_app_IN_OFF  ((uint8_T)1U)
#define stm32f207_template_app_IN_ON   ((uint8_T)2U)

/* Block signals and states (default storage) */
DW_stm32f207_template_app_T stm32f207_template_app_DW;

/* Real-time model */
static RT_MODEL_stm32f207_template_a_T stm32f207_template_app_M_;
RT_MODEL_stm32f207_template_a_T *const stm32f207_template_app_M =
  &stm32f207_template_app_M_;
static void rate_scheduler(void);

/*
 *         This function updates active task flag for each subrate.
 *         The function is called at model base rate, hence the
 *         generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (stm32f207_template_app_M->Timing.TaskCounters.TID[1])++;
  if ((stm32f207_template_app_M->Timing.TaskCounters.TID[1]) > 1) {/* Sample time: [0.02s, 0.0s] */
    stm32f207_template_app_M->Timing.TaskCounters.TID[1] = 0;
  }

  (stm32f207_template_app_M->Timing.TaskCounters.TID[2])++;
  if ((stm32f207_template_app_M->Timing.TaskCounters.TID[2]) > 49) {/* Sample time: [0.5s, 0.0s] */
    stm32f207_template_app_M->Timing.TaskCounters.TID[2] = 0;
  }

  (stm32f207_template_app_M->Timing.TaskCounters.TID[3])++;
  if ((stm32f207_template_app_M->Timing.TaskCounters.TID[3]) > 99) {/* Sample time: [1.0s, 0.0s] */
    stm32f207_template_app_M->Timing.TaskCounters.TID[3] = 0;
  }
}

/*
 * Output and update for function-call system:
 *    '<S2>/�anSendMsg'
 *    '<S2>/�anSendMsg1'
 */
void stm32f207_template_ap_anSendMsg(const CAN_MESSAGE_BUS *rtu_canMsg,
  boolean_T *rty_result)
{
  CAN_Msg_t rtb_BusAssignment;
  int32_T i;

  /* DataTypeConversion: '<S12>/Cast' */
  rtb_BusAssignment.Timestamp = (uint32_T)rtu_canMsg->Timestamp;

  /* BusAssignment: '<S12>/Bus Assignment' */
  rtb_BusAssignment.ID = rtu_canMsg->ID;
  rtb_BusAssignment.Length = rtu_canMsg->Length;
  for (i = 0; i < 8; i++) {
    uint8_T rtu_canMsg_0;
    rtu_canMsg_0 = rtu_canMsg->Data[i];
    rtb_BusAssignment.Data[i] = rtu_canMsg_0;
  }

  rtb_BusAssignment.Extended = rtu_canMsg->Extended;
  rtb_BusAssignment.Remote = rtu_canMsg->Remote;
  rtb_BusAssignment.Error = rtu_canMsg->Error;

  /* End of BusAssignment: '<S12>/Bus Assignment' */

  /* CCaller: '<S12>/CanSendMessage1' incorporates:
   *  Constant: '<S12>/can'
   */
  *rty_result = CanSendMessage(0, &rtb_BusAssignment);
}

/*
 * Output and update for function-call system:
 *    '<S17>/CAN send'
 *    '<S21>/CAN send'
 *    '<S25>/CAN send'
 */
void stm32f207_template_app_CANsend(const CAN_MESSAGE_BUS *rtu_canMsg, boolean_T
  *rty_result)
{
  CAN_Msg_t rtb_BusAssignment;
  int32_T i;
  uint32_T rtb_Cast_h;

  /* DataTypeConversion: '<S18>/Cast' */
  rtb_Cast_h = (uint32_T)rtu_canMsg->Timestamp;

  /* BusAssignment: '<S18>/Bus Assignment' */
  rtb_BusAssignment.ID = rtu_canMsg->ID;
  rtb_BusAssignment.Length = rtu_canMsg->Length;
  for (i = 0; i < 8; i++) {
    uint8_T rtu_canMsg_0;
    rtu_canMsg_0 = rtu_canMsg->Data[i];
    rtb_BusAssignment.Data[i] = rtu_canMsg_0;
  }

  rtb_BusAssignment.Extended = rtu_canMsg->Extended;
  rtb_BusAssignment.Remote = rtu_canMsg->Remote;
  rtb_BusAssignment.Error = rtu_canMsg->Error;
  rtb_BusAssignment.Timestamp = rtb_Cast_h;

  /* End of BusAssignment: '<S18>/Bus Assignment' */

  /* CCaller: '<S18>/CanSendMessage1' incorporates:
   *  Constant: '<S18>/can'
   */
  *rty_result = CanSendMessage(0, &rtb_BusAssignment);
}

/* Model step function */
void simulink_app_step(void)
{
  CAN_Msg_t rtb_CanGetAllMessages1_o2;
  int32_T i;
  int32_T s5_iter;
  uint32_T rtb_CastToDouble;
  uint8_T rtb_Add;
  boolean_T rtb_RelationalOperator1_c[8];
  boolean_T rtb_outBlueLed;
  boolean_T rtb_outGreenLed;
  boolean_T rtb_outRedLed;

  /* Outputs for Atomic SubSystem: '<Root>/CanRx' */
  /* Outputs for Iterator SubSystem: '<S4>/ParsingRxCanMsgs1' incorporates:
   *  WhileIterator: '<S5>/While Iterator'
   */
  s5_iter = 1;

  /* Constant: '<S4>/Constant1' */
  rtb_outRedLed = true;
  while ((boolean_T)((int32_T)(((s5_iter <= 50) ? ((int32_T)1) : ((int32_T)0)) &
           (rtb_outRedLed ? ((int32_T)1) : ((int32_T)0))))) {
    /* Outputs for Atomic SubSystem: '<S5>/�anReceiveMsgFromAll1' */
    /* CCaller: '<S8>/CanGetAllMessages1' incorporates:
     *  Constant: '<S8>/can'
     */
    rtb_outRedLed = CanGetAllMessages(0, &rtb_CanGetAllMessages1_o2);

    /* DataTypeConversion: '<S8>/Cast To Double' */
    rtb_CastToDouble = rtb_CanGetAllMessages1_o2.Timestamp;

    /* BusAssignment: '<S8>/Bus Assignment' */
    stm32f207_template_app_DW.BusAssignment.ID = rtb_CanGetAllMessages1_o2.ID;
    stm32f207_template_app_DW.BusAssignment.Extended =
      rtb_CanGetAllMessages1_o2.Extended;
    for (i = 0; i < 8; i++) {
      stm32f207_template_app_DW.BusAssignment.Data[i] =
        rtb_CanGetAllMessages1_o2.Data[i];
    }

    stm32f207_template_app_DW.BusAssignment.Length =
      rtb_CanGetAllMessages1_o2.Length;
    stm32f207_template_app_DW.BusAssignment.Remote =
      rtb_CanGetAllMessages1_o2.Remote;
    stm32f207_template_app_DW.BusAssignment.Error =
      rtb_CanGetAllMessages1_o2.Error;
    stm32f207_template_app_DW.BusAssignment.Timestamp = (real_T)rtb_CastToDouble;

    /* End of BusAssignment: '<S8>/Bus Assignment' */
    /* End of Outputs for SubSystem: '<S5>/�anReceiveMsgFromAll1' */

    /* If: '<S5>/If' incorporates:
     *  DataTypeConversion: '<S5>/Cast'
     */
    if (rtb_outRedLed) {
      /* Outputs for IfAction SubSystem: '<S5>/If Action Subsystem' incorporates:
       *  ActionPort: '<S7>/Action Port'
       */
      /* S-Function (scanunpack): '<S9>/CAN Unpack' */
      {
        /* S-Function (scanunpack): '<S9>/CAN Unpack' */
        uint8_T msgReceived = 0;
        if ((8 == stm32f207_template_app_DW.BusAssignment.Length) &&
            (stm32f207_template_app_DW.BusAssignment.ID != INVALID_CAN_ID) ) {
          if ((418385749 == stm32f207_template_app_DW.BusAssignment.ID) && (1U ==
               stm32f207_template_app_DW.BusAssignment.Extended) ) {
            msgReceived = 1;
            (void) memcpy(&stm32f207_template_app_DW.CANUnpack_o1[0],
                          stm32f207_template_app_DW.BusAssignment.Data,
                          8 * sizeof(uint8_T));
          }
        }

        /* Status port */
        stm32f207_template_app_DW.CANUnpack_o2 = msgReceived;
      }

      /* DataTypeConversion: '<S9>/Cast To Boolean' */
      stm32f207_template_app_DW.CastToBoolean =
        (stm32f207_template_app_DW.CANUnpack_o1[0] != 0U);

      /* DataTypeConversion: '<S9>/Cast To Boolean1' */
      stm32f207_template_app_DW.CastToBoolean1 =
        (stm32f207_template_app_DW.CANUnpack_o1[1] != 0U);

      /* DataTypeConversion: '<S9>/Cast To Boolean3' */
      stm32f207_template_app_DW.CastToBoolean3 =
        (stm32f207_template_app_DW.CANUnpack_o1[2] != 0U);

      /* End of Outputs for SubSystem: '<S5>/If Action Subsystem' */
    }

    /* End of If: '<S5>/If' */
    s5_iter++;
  }

  /* End of Outputs for SubSystem: '<S4>/ParsingRxCanMsgs1' */
  /* End of Outputs for SubSystem: '<Root>/CanRx' */

  /* Outputs for Atomic SubSystem: '<Root>/MainLogic' */
  if (stm32f207_template_app_M->Timing.TaskCounters.TID[1] == 0) {
    /* Sum: '<S3>/Add' incorporates:
     *  Constant: '<S3>/Constant11'
     *  Delay: '<S3>/Delay One Step'
     */
    rtb_Add = (uint8_T)((uint32_T)stm32f207_template_app_DW.DelayOneStep_DSTATE
                        + 1U);
  }

  /* Chart: '<S3>/Chart' */
  /* Gateway: MainLogic/Chart */
  if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i1 < 31U) {
    stm32f207_template_app_DW.temporalCounter_i1 = (uint8_T)((uint32_T)
      stm32f207_template_app_DW.temporalCounter_i1 + 1U);
  }

  if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i2 < 63U) {
    stm32f207_template_app_DW.temporalCounter_i2 = (uint8_T)((uint32_T)
      stm32f207_template_app_DW.temporalCounter_i2 + 1U);
  }

  if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i3 < 127U) {
    stm32f207_template_app_DW.temporalCounter_i3 = (uint8_T)((uint32_T)
      stm32f207_template_app_DW.temporalCounter_i3 + 1U);
  }

  /* During: MainLogic/Chart */
  if ((uint32_T)stm32f207_template_app_DW.is_active_c3_stm32f207_template == 0U)
  {
    /* Entry: MainLogic/Chart */
    stm32f207_template_app_DW.is_active_c3_stm32f207_template = 1U;

    /* Entry Internal: MainLogic/Chart */
    /* Entry Internal 'RED_LED': '<S29>:25' */
    /* Transition: '<S29>:27' */
    stm32f207_template_app_DW.temporalCounter_i1 = 0U;
    stm32f207_template_app_DW.is_RED_LED = stm32f207_template_app_IN_OFF;

    /* Entry 'OFF': '<S29>:21' */
    /* '<S29>:21:3' outRedLed = true; */
    rtb_outRedLed = true;

    /* Entry Internal 'BLUE_LED': '<S29>:26' */
    /* Transition: '<S29>:28' */
    stm32f207_template_app_DW.temporalCounter_i2 = 0U;
    stm32f207_template_app_DW.is_BLUE_LED = stm32f207_template_app_IN_OFF;

    /* Entry 'OFF': '<S29>:7' */
    /* '<S29>:7:3' outBlueLed = true; */
    rtb_outBlueLed = true;

    /* Entry Internal 'GREEN_LED': '<S29>:29' */
    /* Transition: '<S29>:32' */
    stm32f207_template_app_DW.temporalCounter_i3 = 0U;
    stm32f207_template_app_DW.is_GREEN_LED = stm32f207_template_app_IN_OFF;

    /* Entry 'OFF': '<S29>:12' */
    /* '<S29>:12:3' outGreenLed = true; */
    rtb_outGreenLed = true;
  } else {
    /* During 'RED_LED': '<S29>:25' */
    if ((uint32_T)stm32f207_template_app_DW.is_RED_LED ==
        stm32f207_template_app_IN_OFF) {
      rtb_outRedLed = true;

      /* During 'OFF': '<S29>:21' */
      /* '<S29>:24:1' sf_internal_predicateOutput = after(100, msec); */
      if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i1 >= 10U) {
        /* Transition: '<S29>:24' */
        stm32f207_template_app_DW.temporalCounter_i1 = 0U;
        stm32f207_template_app_DW.is_RED_LED = stm32f207_template_app_IN_ON;

        /* Entry 'ON': '<S29>:22' */
        /* '<S29>:22:3' outRedLed = false; */
        rtb_outRedLed = false;
      }
    } else {
      rtb_outRedLed = false;

      /* During 'ON': '<S29>:22' */
      /* '<S29>:23:1' sf_internal_predicateOutput = after(250, msec); */
      if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i1 >= 25U) {
        /* Transition: '<S29>:23' */
        stm32f207_template_app_DW.temporalCounter_i1 = 0U;
        stm32f207_template_app_DW.is_RED_LED = stm32f207_template_app_IN_OFF;

        /* Entry 'OFF': '<S29>:21' */
        /* '<S29>:21:3' outRedLed = true; */
        rtb_outRedLed = true;
      }
    }

    /* During 'BLUE_LED': '<S29>:26' */
    if ((uint32_T)stm32f207_template_app_DW.is_BLUE_LED ==
        stm32f207_template_app_IN_OFF) {
      rtb_outBlueLed = true;

      /* During 'OFF': '<S29>:7' */
      /* '<S29>:10:1' sf_internal_predicateOutput = after(500, msec); */
      if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i2 >= 50U) {
        /* Transition: '<S29>:10' */
        stm32f207_template_app_DW.temporalCounter_i2 = 0U;
        stm32f207_template_app_DW.is_BLUE_LED = stm32f207_template_app_IN_ON;

        /* Entry 'ON': '<S29>:8' */
        /* '<S29>:8:3' outBlueLed = false; */
        rtb_outBlueLed = false;
      }
    } else {
      rtb_outBlueLed = false;

      /* During 'ON': '<S29>:8' */
      /* '<S29>:9:1' sf_internal_predicateOutput = after(500, msec); */
      if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i2 >= 50U) {
        /* Transition: '<S29>:9' */
        stm32f207_template_app_DW.temporalCounter_i2 = 0U;
        stm32f207_template_app_DW.is_BLUE_LED = stm32f207_template_app_IN_OFF;

        /* Entry 'OFF': '<S29>:7' */
        /* '<S29>:7:3' outBlueLed = true; */
        rtb_outBlueLed = true;
      }
    }

    /* During 'GREEN_LED': '<S29>:29' */
    if ((uint32_T)stm32f207_template_app_DW.is_GREEN_LED ==
        stm32f207_template_app_IN_OFF) {
      rtb_outGreenLed = true;

      /* During 'OFF': '<S29>:12' */
      /* '<S29>:15:1' sf_internal_predicateOutput = after(1000, msec); */
      if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i3 >= 100U) {
        /* Transition: '<S29>:15' */
        stm32f207_template_app_DW.temporalCounter_i3 = 0U;
        stm32f207_template_app_DW.is_GREEN_LED = stm32f207_template_app_IN_ON;

        /* Entry 'ON': '<S29>:13' */
        /* '<S29>:13:3' outGreenLed = false; */
        rtb_outGreenLed = false;
      }
    } else {
      rtb_outGreenLed = false;

      /* During 'ON': '<S29>:13' */
      /* '<S29>:14:1' sf_internal_predicateOutput = after(1000, msec); */
      if ((uint32_T)stm32f207_template_app_DW.temporalCounter_i3 >= 100U) {
        /* Transition: '<S29>:14' */
        stm32f207_template_app_DW.temporalCounter_i3 = 0U;
        stm32f207_template_app_DW.is_GREEN_LED = stm32f207_template_app_IN_OFF;

        /* Entry 'OFF': '<S29>:12' */
        /* '<S29>:12:3' outGreenLed = true; */
        rtb_outGreenLed = true;
      }
    }
  }

  /* End of Chart: '<S3>/Chart' */

  /* Logic: '<S3>/AND2' */
  stm32f207_template_app_DW.BlueSts = stm32f207_template_app_DW.CastToBoolean &
    rtb_outBlueLed;

  /* CCaller: '<S30>/SetLedState1' incorporates:
   *  Constant: '<S30>/Constant'
   *  DataTypeConversion: '<S30>/Cast'
   */
  SetLedState((uint8_T)2U, (uint8_T)stm32f207_template_app_DW.BlueSts);

  /* Logic: '<S3>/AND1' */
  stm32f207_template_app_DW.GreenSts = stm32f207_template_app_DW.CastToBoolean1
    & rtb_outGreenLed;

  /* CCaller: '<S31>/SetLedState1' incorporates:
   *  Constant: '<S31>/Constant'
   *  DataTypeConversion: '<S31>/Cast'
   */
  SetLedState((uint8_T)1U, (uint8_T)stm32f207_template_app_DW.GreenSts);

  /* Logic: '<S3>/AND' */
  stm32f207_template_app_DW.RedSts = stm32f207_template_app_DW.CastToBoolean3 &
    rtb_outRedLed;

  /* CCaller: '<S32>/SetLedState1' incorporates:
   *  Constant: '<S32>/Constant'
   *  DataTypeConversion: '<S32>/Cast'
   */
  SetLedState((uint8_T)3U, (uint8_T)stm32f207_template_app_DW.RedSts);
  if (stm32f207_template_app_M->Timing.TaskCounters.TID[1] == 0) {
    /* Update for Delay: '<S3>/Delay One Step' */
    stm32f207_template_app_DW.DelayOneStep_DSTATE = rtb_Add;

    /* Outputs for Atomic SubSystem: '<Root>/CanTx' */
    /* Outputs for Atomic SubSystem: '<S14>/CanTxPMsg' */
    /* Memory: '<S20>/Memory4' */
    stm32f207_template_app_DW.Memory4_o =
      stm32f207_template_app_DW.Memory4_PreviousInput_e;

    /* S-Function (sdspcount2): '<S20>/Counter' incorporates:
     *  Memory: '<S20>/Memory1'
     */
    if (stm32f207_template_app_DW.Memory4_o) {
      stm32f207_template_app_DW.Counter_Count_n = 0U;
    }

    if (stm32f207_template_app_DW.Memory1_PreviousInput_a != 0U) {
      stm32f207_template_app_DW.Counter_Count_n++;
    }

    /* RelationalOperator: '<S20>/Relational Operator3' incorporates:
     *  Constant: '<S20>/Constant3'
     *  Product: '<S20>/Product'
     *  S-Function (sdspcount2): '<S20>/Counter'
     *  SampleTimeMath: '<S20>/Weighted Sample Time'
     *
     * About '<S20>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_outBlueLed = ((uint32_T)((real32_T)(20.0F * (real32_T)
      stm32f207_template_app_DW.Counter_Count_n)) >= 100U);

    /* Logic: '<S17>/AND' incorporates:
     *  Logic: '<S17>/OR'
     *  Logic: '<S20>/AND1'
     *  Memory: '<S17>/Memory3'
     */
    stm32f207_template_app_DW.AND_l =
      stm32f207_template_app_DW.Memory3_PreviousInput_f | rtb_outBlueLed;

    /* S-Function (fcgen): '<S17>/Function-Call Generator' */
    if (stm32f207_template_app_DW.AND_l) {
      /* Outputs for Function Call SubSystem: '<S17>/CAN send' */
      stm32f207_template_app_CANsend(&stm32f207_template_app_ConstB.CANPack,
        &stm32f207_template_app_DW.CanSendMessage1_m);

      /* End of Outputs for SubSystem: '<S17>/CAN send' */
    }

    /* End of Outputs for S-Function (fcgen): '<S17>/Function-Call Generator' */

    /* Update for Memory: '<S17>/Memory' */
    for (i = 0; i < 8; i++) {
      stm32f207_template_app_DW.Memory_PreviousInput_c[i] =
        stm32f207_template_app_ConstB.CANPack.Data[i];
    }

    /* End of Update for Memory: '<S17>/Memory' */

    /* Update for Memory: '<S20>/Memory1' incorporates:
     *  Constant: '<S20>/Constant2'
     */
    stm32f207_template_app_DW.Memory1_PreviousInput_a = 1U;

    /* Update for Memory: '<S20>/Memory4' */
    stm32f207_template_app_DW.Memory4_PreviousInput_e = rtb_outBlueLed;

    /* Update for Memory: '<S17>/Memory3' incorporates:
     *  RelationalOperator: '<S19>/Compare'
     */
    stm32f207_template_app_DW.Memory3_PreviousInput_f =
      stm32f207_template_app_DW.CanSendMessage1_m ^ 1;

    /* End of Outputs for SubSystem: '<S14>/CanTxPMsg' */
    /* End of Outputs for SubSystem: '<Root>/CanTx' */
  }

  /* End of Outputs for SubSystem: '<Root>/MainLogic' */

  /* Outputs for Atomic SubSystem: '<Root>/CanTx' */
  /* Outputs for Atomic SubSystem: '<S15>/CanTxPMsg' */
  /* RelationalOperator: '<S21>/Relational Operator1' incorporates:
   *  Memory: '<S21>/Memory'
   */
  for (i = 0; i < 8; i++) {
    rtb_RelationalOperator1_c[i] =
      (stm32f207_template_app_ConstB.CANPack3.Data[i] !=
       stm32f207_template_app_DW.Memory_PreviousInput_d[i]);
  }

  /* End of RelationalOperator: '<S21>/Relational Operator1' */

  /* Memory: '<S24>/Memory4' */
  stm32f207_template_app_DW.Memory4_g =
    stm32f207_template_app_DW.Memory4_PreviousInput_m;

  /* S-Function (sdspcount2): '<S24>/Counter' incorporates:
   *  Memory: '<S24>/Memory1'
   */
  if (stm32f207_template_app_DW.Memory4_g) {
    stm32f207_template_app_DW.Counter_Count_k = 0U;
  }

  if (stm32f207_template_app_DW.Memory1_PreviousInput_h != 0U) {
    stm32f207_template_app_DW.Counter_Count_k++;
  }

  /* S-Function (sfix_bitop): '<S21>/Bitwise OR' */
  rtb_outRedLed = rtb_RelationalOperator1_c[0];
  for (s5_iter = 0; s5_iter < 7; s5_iter++) {
    rtb_outRedLed = rtb_RelationalOperator1_c[s5_iter + 1] | rtb_outRedLed;
  }

  /* End of S-Function (sfix_bitop): '<S21>/Bitwise OR' */

  /* RelationalOperator: '<S24>/Relational Operator3' incorporates:
   *  Constant: '<S24>/Constant3'
   *  Product: '<S24>/Product'
   *  S-Function (sdspcount2): '<S24>/Counter'
   *  SampleTimeMath: '<S24>/Weighted Sample Time'
   *
   * About '<S24>/Weighted Sample Time':
   *  y = K where K = ( w * Ts )
   */
  rtb_outBlueLed = ((uint32_T)((real32_T)(10.0F * (real32_T)
    stm32f207_template_app_DW.Counter_Count_k)) >= 250U);

  /* Logic: '<S21>/AND' incorporates:
   *  Logic: '<S21>/OR'
   *  Logic: '<S24>/AND1'
   *  Memory: '<S21>/Memory3'
   */
  stm32f207_template_app_DW.AND_d =
    stm32f207_template_app_DW.Memory3_PreviousInput_j | rtb_outBlueLed;

  /* S-Function (fcgen): '<S21>/Function-Call Generator' */
  if (stm32f207_template_app_DW.AND_d) {
    /* Outputs for Function Call SubSystem: '<S21>/CAN send' */
    stm32f207_template_app_CANsend(&stm32f207_template_app_ConstB.CANPack3,
      &stm32f207_template_app_DW.CanSendMessage1_a);

    /* End of Outputs for SubSystem: '<S21>/CAN send' */
  }

  /* End of Outputs for S-Function (fcgen): '<S21>/Function-Call Generator' */

  /* Update for Memory: '<S21>/Memory' */
  for (i = 0; i < 8; i++) {
    stm32f207_template_app_DW.Memory_PreviousInput_d[i] =
      stm32f207_template_app_ConstB.CANPack3.Data[i];
  }

  /* End of Update for Memory: '<S21>/Memory' */

  /* Update for Memory: '<S24>/Memory1' incorporates:
   *  Constant: '<S24>/Constant2'
   */
  stm32f207_template_app_DW.Memory1_PreviousInput_h = 1U;

  /* Update for Memory: '<S24>/Memory4' */
  stm32f207_template_app_DW.Memory4_PreviousInput_m = rtb_outBlueLed;

  /* Update for Memory: '<S21>/Memory3' incorporates:
   *  RelationalOperator: '<S23>/Compare'
   */
  stm32f207_template_app_DW.Memory3_PreviousInput_j =
    stm32f207_template_app_DW.CanSendMessage1_a ^ 1;

  /* End of Outputs for SubSystem: '<S15>/CanTxPMsg' */
  if (stm32f207_template_app_M->Timing.TaskCounters.TID[1] == 0) {
    /* SignalConversion generated from: '<S2>/CAN Pack4' incorporates:
     *  Constant: '<S3>/Constant10'
     */
    stm32f207_template_app_DW.Data[0] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[1] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[2] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[3] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[4] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[5] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[6] = MAX_uint8_T;
    stm32f207_template_app_DW.Data[7] = rtb_Add;

    /* S-Function (scanpack): '<S2>/CAN Pack4' */
    /* S-Function (scanpack): '<S2>/CAN Pack4' */
    stm32f207_template_app_DW.CANPack4.ID = 418383107U;
    stm32f207_template_app_DW.CANPack4.Length = 8U;
    stm32f207_template_app_DW.CANPack4.Extended = 1U;
    stm32f207_template_app_DW.CANPack4.Remote = 0;
    stm32f207_template_app_DW.CANPack4.Data[0] = 0;
    stm32f207_template_app_DW.CANPack4.Data[1] = 0;
    stm32f207_template_app_DW.CANPack4.Data[2] = 0;
    stm32f207_template_app_DW.CANPack4.Data[3] = 0;
    stm32f207_template_app_DW.CANPack4.Data[4] = 0;
    stm32f207_template_app_DW.CANPack4.Data[5] = 0;
    stm32f207_template_app_DW.CANPack4.Data[6] = 0;
    stm32f207_template_app_DW.CANPack4.Data[7] = 0;

    {
      (void) memcpy((stm32f207_template_app_DW.CANPack4.Data),
                    &stm32f207_template_app_DW.Data[0],
                    8 * sizeof(uint8_T));
    }

    /* Outputs for Atomic SubSystem: '<S16>/CanTxPMsg' */
    /* RelationalOperator: '<S25>/Relational Operator1' incorporates:
     *  Memory: '<S25>/Memory'
     */
    for (i = 0; i < 8; i++) {
      rtb_RelationalOperator1_c[i] = (stm32f207_template_app_DW.CANPack4.Data[i]
        != stm32f207_template_app_DW.Memory_PreviousInput[i]);
    }

    /* End of RelationalOperator: '<S25>/Relational Operator1' */

    /* Memory: '<S28>/Memory4' */
    stm32f207_template_app_DW.Memory4 =
      stm32f207_template_app_DW.Memory4_PreviousInput;

    /* S-Function (sdspcount2): '<S28>/Counter' incorporates:
     *  Memory: '<S28>/Memory1'
     */
    if (stm32f207_template_app_DW.Memory4) {
      stm32f207_template_app_DW.Counter_Count = 0U;
    }

    if (stm32f207_template_app_DW.Memory1_PreviousInput != 0U) {
      stm32f207_template_app_DW.Counter_Count++;
    }

    /* S-Function (sfix_bitop): '<S25>/Bitwise OR' */
    rtb_outRedLed = rtb_RelationalOperator1_c[0];
    for (s5_iter = 0; s5_iter < 7; s5_iter++) {
      rtb_outRedLed = rtb_RelationalOperator1_c[s5_iter + 1] | rtb_outRedLed;
    }

    /* RelationalOperator: '<S28>/Relational Operator3' incorporates:
     *  Constant: '<S28>/Constant3'
     *  Product: '<S28>/Product'
     *  S-Function (sdspcount2): '<S28>/Counter'
     *  SampleTimeMath: '<S28>/Weighted Sample Time'
     *
     * About '<S28>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_outBlueLed = ((uint32_T)((real32_T)(20.0F * (real32_T)
      stm32f207_template_app_DW.Counter_Count)) >= 500U);

    /* Logic: '<S25>/AND' incorporates:
     *  Logic: '<S25>/OR'
     *  Logic: '<S28>/AND1'
     *  Memory: '<S25>/Memory3'
     *  S-Function (sfix_bitop): '<S25>/Bitwise OR'
     */
    stm32f207_template_app_DW.AND = (boolean_T)((int32_T)
      ((stm32f207_template_app_DW.Memory3_PreviousInput ? ((int32_T)1) :
        ((int32_T)0)) | (rtb_outBlueLed ? ((int32_T)1) : ((int32_T)0)))) |
      rtb_outRedLed;

    /* S-Function (fcgen): '<S25>/Function-Call Generator' */
    if (stm32f207_template_app_DW.AND) {
      /* Outputs for Function Call SubSystem: '<S25>/CAN send' */
      stm32f207_template_app_CANsend(&stm32f207_template_app_DW.CANPack4,
        &stm32f207_template_app_DW.CanSendMessage1);

      /* End of Outputs for SubSystem: '<S25>/CAN send' */
    }

    /* End of Outputs for S-Function (fcgen): '<S25>/Function-Call Generator' */

    /* Update for Memory: '<S25>/Memory' */
    for (i = 0; i < 8; i++) {
      stm32f207_template_app_DW.Memory_PreviousInput[i] =
        stm32f207_template_app_DW.CANPack4.Data[i];
    }

    /* End of Update for Memory: '<S25>/Memory' */

    /* Update for Memory: '<S28>/Memory1' incorporates:
     *  Constant: '<S28>/Constant2'
     */
    stm32f207_template_app_DW.Memory1_PreviousInput = 1U;

    /* Update for Memory: '<S28>/Memory4' */
    stm32f207_template_app_DW.Memory4_PreviousInput = rtb_outBlueLed;

    /* Update for Memory: '<S25>/Memory3' incorporates:
     *  RelationalOperator: '<S27>/Compare'
     */
    stm32f207_template_app_DW.Memory3_PreviousInput =
      stm32f207_template_app_DW.CanSendMessage1 ^ 1;

    /* End of Outputs for SubSystem: '<S16>/CanTxPMsg' */
  }

  if (stm32f207_template_app_M->Timing.TaskCounters.TID[3] == 0) {
    /* S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
     *  SubSystem: '<S2>/�anSendMsg'
     */
    stm32f207_template_ap_anSendMsg(&stm32f207_template_app_ConstB.CANPack1,
      &rtb_outRedLed);

    /* End of Outputs for S-Function (fcgen): '<S2>/Function-Call Generator' */
  }

  if (stm32f207_template_app_M->Timing.TaskCounters.TID[2] == 0) {
    /* S-Function (fcgen): '<S2>/Function-Call Generator1' incorporates:
     *  SubSystem: '<S2>/�anSendMsg1'
     */
    stm32f207_template_ap_anSendMsg(&stm32f207_template_app_ConstB.CANPack2,
      &rtb_outRedLed);

    /* End of Outputs for S-Function (fcgen): '<S2>/Function-Call Generator1' */
  }

  /* End of Outputs for SubSystem: '<Root>/CanTx' */
  rate_scheduler();
}

/* Model initialize function */
void simulink_app_initialize(void)
{
  /* SystemInitialize for Atomic SubSystem: '<Root>/CanRx' */
  /* SystemInitialize for Iterator SubSystem: '<S4>/ParsingRxCanMsgs1' */
  /* SystemInitialize for IfAction SubSystem: '<S5>/If Action Subsystem' */
  /* Start for S-Function (scanunpack): '<S9>/CAN Unpack' */

  /*-----------S-Function Block: <S9>/CAN Unpack -----------------*/

  /* End of SystemInitialize for SubSystem: '<S5>/If Action Subsystem' */
  /* End of SystemInitialize for SubSystem: '<S4>/ParsingRxCanMsgs1' */
  /* End of SystemInitialize for SubSystem: '<Root>/CanRx' */
}

/* Model terminate function */
void simulink_app_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
