/*
 * File: simulink_app.h
 *
 * Code generated for Simulink model 'stm32f207_template_app'.
 *
 * Model version                  : 1.562
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Sat Jul  5 22:55:16 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. MISRA C:2012 guidelines
 *    2. Execution efficiency
 *    3. ROM efficiency
 *    4. RAM efficiency
 *    5. Traceability
 *    6. Safety precaution
 *    7. Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_simulink_app_h_
#define RTW_HEADER_simulink_app_h_
#ifndef stm32f207_template_app_COMMON_INCLUDES_
#define stm32f207_template_app_COMMON_INCLUDES_
#include <math.h>
#include "rtwtypes.h"
#endif                             /* stm32f207_template_app_COMMON_INCLUDES_ */

#include "simulink_apptypes.h"
#include "can_control.h"
#include <string.h>

/* user code (top of header file) */
#include "rtmodel.h"

/* Block signals and states (default storage) for system '<Root>' */
typedef struct {
  CAN_MESSAGE_BUS CANPack4;            /* '<Root>/CAN Pack4' */
  uint32_T Memory1_PreviousInput;      /* '<S22>/Memory1' */
  uint32_T Counter_Count;              /* '<S22>/Counter' */
  uint32_T Memory1_PreviousInput_h;    /* '<S18>/Memory1' */
  uint32_T Counter_Count_k;            /* '<S18>/Counter' */
  uint32_T Memory1_PreviousInput_a;    /* '<S14>/Memory1' */
  uint32_T Counter_Count_n;            /* '<S14>/Counter' */
  uint8_T TmpSignalConversionAtCANPack4In[8];
  uint8_T Memory_PreviousInput[8];     /* '<S19>/Memory' */
  uint8_T Memory_PreviousInput_d[8];   /* '<S15>/Memory' */
  uint8_T Memory_PreviousInput_c[8];   /* '<S11>/Memory' */
  uint8_T DelayOneStep_DSTATE;         /* '<Root>/Delay One Step' */
  uint8_T is_active_c3_stm32f207_template;/* '<S1>/Chart' */
  uint8_T is_RED_LED;                  /* '<S1>/Chart' */
  uint8_T is_BLUE_LED;                 /* '<S1>/Chart' */
  uint8_T is_GREEN_LED;                /* '<S1>/Chart' */
  uint8_T temporalCounter_i1;          /* '<S1>/Chart' */
  uint8_T temporalCounter_i2;          /* '<S1>/Chart' */
  uint8_T temporalCounter_i3;          /* '<S1>/Chart' */
  boolean_T Memory4;                   /* '<S22>/Memory4' */
  boolean_T AND;                       /* '<S19>/AND' */
  boolean_T CanSendMessage1;           /* '<S20>/CanSendMessage1' */
  boolean_T Memory4_g;                 /* '<S18>/Memory4' */
  boolean_T AND_d;                     /* '<S15>/AND' */
  boolean_T CanSendMessage1_a;         /* '<S16>/CanSendMessage1' */
  boolean_T Memory4_o;                 /* '<S14>/Memory4' */
  boolean_T AND_l;                     /* '<S11>/AND' */
  boolean_T CanSendMessage1_m;         /* '<S12>/CanSendMessage1' */
  boolean_T BlueSts;                   /* '<S1>/AND2' */
  boolean_T GreenSts;                  /* '<S1>/AND1' */
  boolean_T RedSts;                    /* '<S1>/AND' */
  boolean_T Memory4_PreviousInput;     /* '<S22>/Memory4' */
  boolean_T Memory3_PreviousInput;     /* '<S19>/Memory3' */
  boolean_T Memory4_PreviousInput_m;   /* '<S18>/Memory4' */
  boolean_T Memory3_PreviousInput_j;   /* '<S15>/Memory3' */
  boolean_T Memory4_PreviousInput_e;   /* '<S14>/Memory4' */
  boolean_T Memory3_PreviousInput_f;   /* '<S11>/Memory3' */
} DW_stm32f207_template_app_T;

/* Invariant block signals for system '<Root>/�anSendMsg' */
typedef struct {
  const CAN_Msg_t BusAssignment;       /* '<S2>/Bus Assignment' */
  const uint32_T Cast;                 /* '<S2>/Cast' */
} ConstB_anSendMsg_stm32f207_te_T;

/* Invariant block signals (default storage) */
typedef struct {
  const CAN_MESSAGE_BUS CANPack;       /* '<Root>/CAN Pack' */
  const CAN_MESSAGE_BUS CANPack1;      /* '<Root>/CAN Pack1' */
  const CAN_MESSAGE_BUS CANPack2;      /* '<Root>/CAN Pack2' */
  const CAN_MESSAGE_BUS CANPack3;      /* '<Root>/CAN Pack3' */
  ConstB_anSendMsg_stm32f207_te_T anSendMsg1;/* '<Root>/�anSendMsg1' */
  ConstB_anSendMsg_stm32f207_te_T anSendMsg;/* '<Root>/�anSendMsg' */
} ConstB_stm32f207_template_app_T;

/* Real-time Model Data Structure */
struct tag_RTM_stm32f207_template_ap_T {
  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    struct {
      uint8_T TID[4];
    } TaskCounters;
  } Timing;
};

/* Block signals and states (default storage) */
extern DW_stm32f207_template_app_T stm32f207_template_app_DW;
extern const ConstB_stm32f207_template_app_T stm32f207_template_app_ConstB;/* constant block i/o */

/* Model entry point functions */
extern void simulink_app_initialize(void);
extern void simulink_app_step(void);
extern void simulink_app_terminate(void);

/* Exported data declaration */

/* Volatile memory section */
/* Declaration for custom storage class: Volatile */
extern volatile boolean_T BlueSwitch;  /* Referenced by: '<S1>/Constant' */
extern volatile boolean_T GreenSwitch; /* Referenced by: '<S1>/Constant1' */
extern volatile boolean_T RedSwitch;   /* Referenced by: '<S1>/Constant2' */

/* Real-time Model object */
extern RT_MODEL_stm32f207_template_a_T *const stm32f207_template_app_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'stm32f207_template_app'
 * '<S1>'   : 'stm32f207_template_app/MainLogic'
 * '<S2>'   : 'stm32f207_template_app/�anSendMsg'
 * '<S3>'   : 'stm32f207_template_app/�anSendMsg1'
 * '<S4>'   : 'stm32f207_template_app/�anSendPeriodMsg'
 * '<S5>'   : 'stm32f207_template_app/�anSendPeriodMsg1'
 * '<S6>'   : 'stm32f207_template_app/�anSendPeriodMsg2'
 * '<S7>'   : 'stm32f207_template_app/MainLogic/Chart'
 * '<S8>'   : 'stm32f207_template_app/MainLogic/LedControl'
 * '<S9>'   : 'stm32f207_template_app/MainLogic/LedControl1'
 * '<S10>'  : 'stm32f207_template_app/MainLogic/LedControl2'
 * '<S11>'  : 'stm32f207_template_app/�anSendPeriodMsg/CanTxPMsg'
 * '<S12>'  : 'stm32f207_template_app/�anSendPeriodMsg/CanTxPMsg/CAN send'
 * '<S13>'  : 'stm32f207_template_app/�anSendPeriodMsg/CanTxPMsg/Compare To Constant'
 * '<S14>'  : 'stm32f207_template_app/�anSendPeriodMsg/CanTxPMsg/PeriodSendGenerator'
 * '<S15>'  : 'stm32f207_template_app/�anSendPeriodMsg1/CanTxPMsg'
 * '<S16>'  : 'stm32f207_template_app/�anSendPeriodMsg1/CanTxPMsg/CAN send'
 * '<S17>'  : 'stm32f207_template_app/�anSendPeriodMsg1/CanTxPMsg/Compare To Constant'
 * '<S18>'  : 'stm32f207_template_app/�anSendPeriodMsg1/CanTxPMsg/PeriodSendGenerator'
 * '<S19>'  : 'stm32f207_template_app/�anSendPeriodMsg2/CanTxPMsg'
 * '<S20>'  : 'stm32f207_template_app/�anSendPeriodMsg2/CanTxPMsg/CAN send'
 * '<S21>'  : 'stm32f207_template_app/�anSendPeriodMsg2/CanTxPMsg/Compare To Constant'
 * '<S22>'  : 'stm32f207_template_app/�anSendPeriodMsg2/CanTxPMsg/PeriodSendGenerator'
 */

/*-
 * Requirements for '<Root>': stm32f207_template_app

 */
#endif                                 /* RTW_HEADER_simulink_app_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
